import React from 'react';

export default function Footer(){
    return(
        <div className="border-top">
            <p style={{textAlign:'center',fontSize:'12px',fontFamily:'serif'}}>Copyright &copy; OMICORE ART GALLERY 2020.All Rights Reserved. <strong>Developed by Ajharali</strong></p>
        </div>
        
    )
}