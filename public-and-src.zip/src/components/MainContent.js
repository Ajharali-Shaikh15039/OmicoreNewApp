import React from 'react'

const MainContent = () => {
    return ( 
            <div class="text-center" text-align="center! important">
                <img src="./logo_omicore.png" height="500px" width="500px" class="img-fluid" alt="..."></img>
            </div>
        
    )
}
export default MainContent;
