const product_card = [
    {
        id: 1001,
        product_name: "Painting",
        description: "COMING SOON",
        // price: 350,
        // currency: "$",
        thumb: "./images/p1.png",
        category: "PAINTING"
    },
    {
        id: 2001,
        product_name: "TABLE FIGURINES",
        description: "IRON PAINTED LONG GIRFFE (SET OF 2 ) BIG",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf1.png",
        category: "TABLE FIGURINES"
    },
    {
        id: 2002,
        product_name: " Table Figurines",
        description: "IRON PAINTED DANCING DANDIA ( SET OF2 ) ",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf2.png",
        category: "TABLE FIGURINES"
    },
    {
        id: 2003,
        product_name: " Table Figurines",
        description: "MUSICAL IRON PAINTED LADY ( SET OF 3 ) ",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf3.png",
        category: "TABLE FIGURINES"
    },{
        id: 2004,
        product_name: " Table Figurines",
        description: "MUSICAL SITTING PAGDI MEN ( SET OF 3 ) ",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf4.png",
        category: "TABLE FIGURINES"
    },{
        id: 2005,
        product_name: " Table Figurines",
        description: "MUSICAL SITTING MEN IRON PAINTED ( SET OF 3 ) ",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf5.png",
        category: "TABLE FIGURINES"
    },{
        id: 2006,
        product_name: " Table Figurines",
        description: "IRON PAINTED MUSICAL KRISHNA (SET OF 3)",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf6.png",
        category: "TABLE FIGURINES"
    },{
        id: 2007,
        product_name: "TABLE FIGURINES",
        description: "IRON PAINTED WORKER LADY (SET OF 4) red",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf7.png",
        category: "TABLE FIGURINES"
    },{
        id: 2008,
        product_name: " Table Figurines",
        description: "IRON PAINTED MUSICAL SITTING MAN (SET OF3)",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf8.png",
        category: "TABLE FIGURINES"
    },{
        id: 2009,
        product_name: " Table Figurines",
        description: "MUSICAL PAGDI MULTICOLOR MEN (SET OF 3) ",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf9.png",
        category: "TABLE FIGURINES"
    },{
        id: 2010,
        product_name: "TABLE FIGURINES",
        description: "MUSICAL PAGDI MULTICOLOR MEN (SET OF 3) S/2 ",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf10.png",
        category: "TABLE FIGURINES"
    },{
        id: 2011,
        product_name: " Table Figurines",
        description: "MUSICAL GANESHA MULTCOLOR MUSICIAN (SET OF 3)",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf11.png",
        category: "TABLE FIGURINES"
    },{
        id: 2012,
        product_name: " Table Figurines",
        description: "MULTICOLOR SWAN IRON PAINTED TABLE TOP ( SET OF 2 )",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf12.png",
        category: "TABLE FIGURINES"
    },{
        id: 2013,
        product_name: " Table Figurines",
        description: "IRON PAINTED LONG DEER (SET OF 2 ) BIG",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf13.png",
        category: "TABLE FIGURINES"
    },{
        id: 2014,
        product_name: " Table Figurines",
        description: "IRON PAINTED CRANE TEA LIGHT (SET OF 2 )",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf14.jpg",
        category: "TABLE FIGURINES"
    },{
        id: 2015,
        product_name: " Table Figurines",
        description: "MULTICOLOR SWAN IRON PAINTED TABLE TOP ( SET OF 2 ) S/2",
        // price: 250,
        // currency: "$",
        thumb: "./images/tf15.png",
        category: "TABLE FIGURINES"
    },
    {
        id: 3001,
        product_name: "Tea light",
        description: "IRON PAINTED TEA LIGHT HANDI W / HANDLE",
        // price: 350,
        // currency: "$",
        thumb: "./images/tl1.png",
        category: "TEA LIGHTS"
    },
    {
        id: 3002,
        product_name: "Tea light",
        description: "IRON PAINTED TEA LIGHT ROUND / HANDLE",
        // price: 350,
        // currency: "$",
        thumb: "./images/tl2.png",
        category: "TEA LIGHTS"
    },{
        id: 3003,
        product_name: "Tea light",
        description: "IRON PAINTED TEA LIGHT BUCKET / HANDLE",
        // price: 350,
        // currency: "$",
        thumb: "./images/tl3.png",
        category: "TEA LIGHTS"
    },{
        id: 3004,
        product_name: "Tea light",
        description: "IRON PAINTED TEA LIGHT S/2 W / HANDLE",
        // price: 350,
        // currency: "$",
        thumb: "./images/tl4.png",
        category: "TEA LIGHTS"
    },{
        id: 3005,
        product_name: "Tea light",
        description: "IRON PAINTED TEA LIGHT LANTERN (S/2)",
        // price: 350,
        // currency: "$",
        thumb: "./images/tl5.png",
        category: "TEA LIGHTS"
    },{
        id: 3006,
        product_name: "Tea light",
        description: "IRON PAINTED TEA LIGHT LANTERN S/2 JALI",
        // price: 350,
        // currency: "$",
        thumb: "./images/tl6.png",
        category: "TEA LIGHTS"
    },{
        id: 3007,
        product_name: "Tea light",
        description: "IRON PAINTED TEA LIGHT BIRD / HANDLE",
        // price: 350,
        // currency: "$",
        thumb: "./images/tl7.jpg",
        category: "TEA LIGHTS"
    },{
        id: 3008,
        product_name: "Tea light",
        description: " IRON PAINTED TEA LIGHT / ELEPHANT",
        // price: 350,
        // currency: "$",
        thumb: "./images/tl8.jpg",
        category: "TEA LIGHTS"
    },{
        id: 3009,
        product_name: "Tea light",
        description: "IRON PAINTED PEACOCK TEALIGHT",
        // price: 350,
        // currency: "$",
        thumb: "./images/tl9.jpg",
        category: "TEA LIGHTS"
    },{
        id: 3010,
        product_name: "Tea light",
        description: "IRON PAINTED GANESHA TEALIGHT",
        // price: 350,
        // currency: "$",
        thumb: "./images/tl10.jpg",
        category: "TEA LIGHTS"
    },
    {
        id: 4001,
        product_name: "Hanging panel",
        description: "IRON PAINTED WALL MUSICAL 5 LADY FRAME",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp1.jpg",
        category: "HANGING PANEL"
    },
    {
        id: 4002,
        product_name: "Hanging panel",
        description: "IRON PAINTED WALL MUSICAL 5 LADY FRAME",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp2.jpg",
        category: "HANGING PANEL"
    },{
        id: 4003,
        product_name: "Hanging panel",
        description: "IRON PAINTED WALL MUSICAL 3 SITTING MAN FRAME",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp3.jpg",
        category: "HANGING PANEL"
    },{
        id: 4004,
        product_name: "Hanging panel",
        description: "IRON PAINTED WALL CAMEL FRAME",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp4.jpg",
        category: "HANGING PANEL"
    },{
        id: 4005,
        product_name: "Hanging panel",
        description: " IRON PAINTED WALL 5 LADY FRAME",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp5.jpg",
        category: "HANGING PANEL"
    },{
        id: 4006,
        product_name: "Hanging panel",
        description: "IRON PAINTED WALL HORSE FRAME ",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp6.jpg",
        category: "HANGING PANEL"
    },{
        id: 4007,
        product_name: "Hanging panel",
        description: "IRON PAINTED WALL MUSICAL 3 SITTING MAN FRAME",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp7.jpg",
        category: "HANGING PANEL"
    },{
        id: 4008,
        product_name: "Hanging panel",
        description: "IRON PAINTED WALL MUSICAL 3 LADY FRAME",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp8.jpg",
        category: "HANGING PANEL"
    },{
        id: 4009,
        product_name: "Hanging panel",
        description: "IRON PAINTED WALL MUSICAL 3 SARDAR FRAME",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp9.jpg",
        category: "HANGING PANEL"
    },{
        id: 4010,
        product_name: "Hanging panel",
        description: "IRON PAINTED WALL MUSICAL 3 SITTING MAN FRAME",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp10.jpg",
        category: "HANGING PANEL"
    },{
        id: 4011,
        product_name: "Hanging panel",
        description: "PEACOCK IRON PAINTED WALL HANGING METAL PANEL ",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp11.jpg",
        category: "HANGING PANEL"
    },{
        id: 4012,
        product_name: "Hanging panel",
        description: "TREE STYLE IRON PAINTED HANDICRAFT WALL HANGING PANEL",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp12.jpg",
        category: "HANGING PANEL"
    },{
        id: 4013,
        product_name: "Hanging panel",
        description: "MULTICOLOR FLOWER VASE STYLE IRON PAINTED WALL HANGING PANEL",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp13.jpg",
        category: "HANGING PANEL"
    },{
        id: 4014,
        product_name: "Hanging panel",
        description: "MULTICOLOR IRON PAINTED WALL HANGING TREE PANEL",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp14.jpg",
        category: "HANGING PANEL"
    },{
        id: 4015,
        product_name: "Hanging panel",
        description: "IRON PAINTED WALL MUSICAL 3 SITTING MAN FRAME",
        // price: 350,
        // currency: "$",
        thumb: "./images/hp15.jpg",
        category: "HANGING PANEL"
    },
    {
        id: 5001,
        product_name: "Mask",
        description: "VOILET TRIBAL WOODEN WALL MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m1.jpg",
        category: "MASK"
    },
    {
        id: 5002,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m2.jpg",
        category: "MASK"
    },{
        id: 5003,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m3.jpg",
        category: "MASK"
    },{
        id: 5004,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m4.jpg",
        category: "MASK"
    },{
        id: 5005,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m5.jpg",
        category: "MASK"
    },{
        id: 5006,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m6.jpg",
        category: "MASK"
    },{
        id: 5007,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m7.jpg",
        category: "MASK"
    },{
        id: 5008,
        product_name: "Mask",
        description: "IRON TRIBAL MASK PAIR",
        // price: 250,
        // currency: "$",
        thumb: "./images/m8.jpg",
        category: "MASK"
    },{
        id: 5009,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m9.jpg",
        category: "MASK"
    },{
        id: 5010,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m10.jpg",
        category: "MASK"
    },{
        id: 5011,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m11.jpg",
        category: "MASK"
    },{
        id: 5012,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK ",
        // price: 250,
        // currency: "$",
        thumb: "./images/m12.jpg",
        category: "MASK"
    },{
        id: 5013,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m13.jpg",
        category: "MASK"
    },{
        id: 5014,
        product_name: "Mask",
        description: "MULTICOLOR TRIBAL WOODEN MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m14.jpg",
        category: "MASK"
    },{
        id: 5015,
        product_name: "Mask",
        description: "RED TRIBAL MASK",
        // price: 250,
        // currency: "$",
        thumb: "./images/m15.jpg",
        category: "MASK"
    },
    {
        id: 6,
        product_name: "Clock",
        description: "Coming Soon",
        // price: 350,
        // currency: "$",
        thumb: "./images/c1.png",
        category: "CLOCK"
    },
    {
        id: 7001,
        product_name: " ",
        description: "HANDCRAFTED CERAMIC HANDI POTTERY ( RED )",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp1.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7002,
        product_name: " ",
        description: "HANDCRAFTED CERAMIC HANDI POTTERY ( LIGHT BLUE )",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp2.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7003,
        product_name: " ",
        description: "HANDCRAFTED CERAMIC HANDI POTTERY ( YELLOW )",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp3.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7004,
        product_name: " ",
        description: " HANDCRAFT POTTERY SOUP BOWL ( GREEN )",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp4.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7005,
        product_name: " ",
        description: "HANDCRAFT POTTERY SOUP BOWL ( ORANGE ) ",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp5.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7006,
        product_name: " ",
        description: "HANDCRAFT POTTERY SOUP BOWL ( YELLOW ",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp6.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7007,
        product_name: " ",
        description: "HANDMADE CRAFT POTTERY MUG ( RED )",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp7.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7008,
        product_name: " ",
        description: "MULTICOLOR HANDCRAFTE POTTERY MUG ",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp8.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7009,
        product_name: " ",
        description: "GREEN CERAMIC DÉCOR PLATE FOR WALL DECORATION",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp9.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7010,
        product_name: " ",
        description: "BLUE POTTERY CERAMIC HANDI HANDCRAFTED POTTERY",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp10.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7011,
        product_name: " ",
        description: "BLUE POTTERY CERAMIC FLOWER POT HANDCRAFTED POTTERY",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp11.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7012,
        product_name: " ",
        description: "BLUE POTTERY CERAMIC WHITE FLOWER POT HANDCRAFTED",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp12.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7013,
        product_name: " ",
        description: "BLUE POTTERY CERAMIC SMALL JAR HANDCRAFTED",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp13.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7014,
        product_name: " ",
        description: "BLUE POTTERY CERAMIC BLUE FLOWER POT HANDCRAFTED",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp14.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7015,
        product_name: " ",
        description: "CERAMIC PLATE FOR TABLE SERVING AND DÉCOR",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp15.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7016,
        product_name: " ",
        description: "BLUE POTTERY CERAMIC PLATES HANDCARFTED POTTERY ( SMALL )",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp16.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7017,
        product_name: " ",
        description: "MULTICOLOR CERAMIC FLOWER VASE POT",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp17.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7018,
        product_name: " ",
        description: "BLUE POTTERY CERAMIC PLATES HANDCARFTED POTTERY S/2",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp18.png",
        category: "BLUE POTTERY"
    },
    {
        id: 7019,
        product_name: " ",
        description: "BLUE POTTERY CERAMIC PLATES HANDCARFTED POTTERY",
        // price: 350,
        // currency: "$",
        thumb: "./images/bp19.png",
        category: "BLUE POTTERY"
    },    
    {
        id: 8001,
        product_name: " ",
        description: "IRON PAINTED BLACK PENDNT LAMP",
        // price: 250,
        // currency: "$",
        thumb: "./images/pl1.jpeg",
        category: "PENDANT LAMP"
    },
    {
        id: 8002,
        product_name: " ",
        description: "IRON PAINTED GOLDEN OWEL SHAPE PENDENT LAMP",
        // price: 250,
        // currency: "$",
        thumb: "./images/pl2.jpeg",
        category: "PENDANT LAMP"
    },{
        id: 8003,
        product_name: " ",
        description: "IRON PAINTED GOLDEN SEMI CIRCULER PENDENT LAMP",
        // price: 250,
        // currency: "$",
        thumb: "./images/pl3.jpeg",
        category: "PENDANT LAMP"
    },{
        id: 8004,
        product_name: " ",
        description: " IRON PAINTED PENDENT LAMP ( ROUND )",
        // price: 250,
        // currency: "$",
        thumb: "./images/pl4.jpeg",
        category: "PENDANT LAMP"
    },{
        id: 8005,
        product_name: " ",
        description: "IRON PAINTED PENDENT LAMP ( RED )",
        // price: 250,
        // currency: "$",
        thumb: "./images/pl5.jpeg",
        category: "PENDANT LAMP"
    },{
        id: 8006,
        product_name: " ",
        description: "IRON PAINTED PENDENT LAMP ( HEXAGONAL )",
        // price: 250,
        // currency: "$",
        thumb: "./images/pl6.jpeg",
        category: "PENDANT LAMP"
    },{
        id: 8007,
        product_name: " ",
        description: "RED IRON PAINTED PENDENT LAMP ( NEST SHAPE )",
        // price: 250,
        // currency: "$",
        thumb: "./images/pl7.jpeg",
        category: "PENDANT LAMP"
    },
    {
        id: 9001,
        product_name: " ",
        description: "IRON PAINTED BROWN TRADITIONAL FLOWER VASE S/3",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv1.jpg",
        category: "FLOWER VASE"
    },
    {
        id: 9002,
        product_name: " ",
        description: "IRON PAINTED GOLDEN TRADITIONAL FLOWER VASE S/2",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv2.jpg",
        category: "FLOWER VASE"
    },
    {
        id: 9003,
        product_name: " ",
        description: "IRON PAINTED RED/BLUE TRADITIONAL FLOWER VASE",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv3.jpg",
        category: "FLOWER VASE"
    },
    {
        id: 9004,
        product_name: " ",
        description: "GOLDEN IRON PAINTED FLOWER VASE ( SET OF 3 )",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv4.jpg",
        category: "FLOWER VASE"
    },{
        id: 9005,
        product_name: " ",
        description: "MULTICOLOR IRON PAINTED CAMEL FLOWER VASE",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv5.jpg",
        category: "FLOWER VASE"
    },
    {
        id: 9006,
        product_name: " ",
        description: "MULTICOLOR IRON PAINTED HORSE FLOWER VASE",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv6.jpg",
        category: "FLOWER VASE"
    },
    {
        id: 9007,
        product_name: " ",
        description: "MULTICOLOR IRON PAINTED DUCK FLOWER VASE",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv7.jpg",
        category: "FLOWER VASE"
    },
    {
        id: 9008,
        product_name: " ",
        description: "TRADITIONAL BROWN IRON PAINTED FLOWER VASE S/2",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv8.jpg",
        category: "FLOWER VASE"
    },{
        id: 9009,
        product_name: " ",
        description: "TRADITIONAL BROWN IRON PAINTED FLOWER VASE",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv9.jpg",
        category: "FLOWER VASE"
    },
    {
        id: 9010,
        product_name: " ",
        description: "TRADITIONAL YELLOW IRON PAINTED FLOWER VASE",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv10.jpg",
        category: "FLOWER VASE"
    },{
        id: 9011,
        product_name: " ",
        description: "TRADITIONAL GOLDEN IRON PAINTED FLOWER VASE",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv11.jpg",
        category: "FLOWER VASE"
    },
    {
        id: 9012,
        product_name: " ",
        description: "TRADITIONAL GREY IRON PAINTED FLOWER VASE",
        // price: 350,
        // currency: "$",
        thumb: "./images/fv12.jpg",
        category: "FLOWER VASE"
    },
    {
        id: 1001,
        product_name: " ",
        description: "GOLDEN ROSE IRON PAINTED WALL MIRROR",
        // price: 350,
        // currency: "$",
        thumb: "./images/mr1.jpg",
        category: "MIRROR"
    },
    {
        id: 1002,
        product_name: " ",
        description: "BROWN LEAF IRON PAINTED WALL MIRROR",
        // price: 350,
        // currency: "$",
        thumb: "./images/mr2.jpg",
        category: "MIRROR"
    },
    {
        id: 1003,
        product_name: " ",
        description: "GOLDEN CIRCLE PATCH IRON PAINTED WALL MIRROR",
        // price: 350,
        // currency: "$",
        thumb: "./images/mr3.jpg",
        category: "MIRROR"
    },
    {
        id: 1004,
        product_name: " ",
        description: "GOLDEN LEAF IRON PAINTED WALL MIRROR",
        // price: 350,
        // currency: "$",
        thumb: "./images/mr4.jpg",
        category: "MIRROR"
    },{
        id: 1005,
        product_name: " ",
        description: "WHITE LEAF IRON PAINTED WALL MIRROR",
        // price: 350,
        // currency: "$",
        thumb: "./images/mr5.jpg",
        category: "MIRROR"
    },{
        id: 1006,
        product_name: " ",
        description: "GOLDEN BUTTERFLY CIRCLE SHAPE WALL MIRROR",
        // price: 350,
        // currency: "$",
        thumb: "./images/mr6.jpg",
        category: "MIRROR"
    },{
        id: 1007,
        product_name: " ",
        description: "RED ROSE IRON PAINTED WALL MIRROR",
        // price: 350,
        // currency: "$",
        thumb: "./images/mr7.jpg",
        category: "MIRROR"
    },{
        id: 1008,
        product_name: " ",
        description: "GOLDEN SUNFLOWER IRON PAINTED WALL MIRROR",
        // price: 350,
        // currency: "$",
        thumb: "./images/mr8.png",
        category: "MIRROR"
    },
]
export default product_card;